function [lat] = dcm2lat(D,conv)
% This function computes the latitude and longitude of
% a point on the earth from the direction cosine matrix
% that transforms the local level coordinates to the earth
% frame.
lat = atan2(D(2,3),sqrt(1-D(2,3)^2));
if conv=='deg'
    lat = lat * 180/pi;
end
return;