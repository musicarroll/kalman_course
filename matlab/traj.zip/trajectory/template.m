function [X,Y,...] = FunctionName(A,B,...)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                        COPYRIGHT (C) 2002 BY                          %
%             BEI Systron Donner Inertial Division                      %
%                      CONCORD, CALIFORNIA                              %
%                      ALL RIGHTS RESERVED.                             %
%                                                                       %
% This software is furnished under a license and may be used and copied %
% only in accordance with the terms of such license and with the        %
% inclusion of the above copyright notice.  This software or any other  %
% copies thereof may not be provided or otherwise made available to any %
% other person.  No title to and ownership of the software is hereby    %
% transferred.                                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File Name:
%
%
% Related Programs and Documents:
%
%
% Run-time Environment Constraints:
%
%
%
%    DESCRIPTION:
%		A collection of somewhat useful Matlab m-file functions for m-file
%		programs that do ...
%
%					NOT CHECKED AFTER INCLUSION HERE
%
% Revision History:  <note: the first record should be the original release>
% Date		Author		SCR #		Change
% ----		------		-----		------------------------------------------
% 9/16/02	dgit		0123		Initial version
% 9/17/02	dgit		0123		Modified header format per sbon's suggestion
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/ 

% local definitions
%	none	<or definitions if there are any>

% default settings
%	none	<or settings>

% external functions

% external string

% internal functions	<list of functions in this file>

% global data

% local data

% public functions

function [X,Y,...] = FunctionName(A,B,...)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Function description:
%	
%
%	Returns:
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/

% private functions

%
%
%    $History: template.m $
% * *****************  Version 1  *****************
% * User: Mcar         Date: 10/23/02    Time: 9:37a
% * Created in $/Standard Templates
% * Initial version of templates for m-files
%
