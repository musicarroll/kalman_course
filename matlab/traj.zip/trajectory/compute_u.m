function [U] = compute_u(P)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                        COPYRIGHT (C) 2002 BY                          %
%             BEI Systron Donner Inertial Division                      %
%                      CONCORD, CALIFORNIA                              %
%                      ALL RIGHTS RESERVED.                             %
%                                                                       %
% This software is furnished under a license and may be used and copied %
% only in accordance with the terms of such license and with the        %
% inclusion of the above copyright notice.  This software or any other  %
% copies thereof may not be provided or otherwise made available to any %
% other person.  No title to and ownership of the software is hereby    %
% transferred.                                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File Name:  compute_u.m
%
%
% Related Programs and Documents:  compute_ud.m
%
%
% Run-time Environment Constraints:  Must run in Matlab.
%
%
%
%    DESCRIPTION:
% This function is a wrapper around compute_ud to return
% only the U unit upper triangular matrix of the UD decomposition.
%
%					NOT CHECKED AFTER INCLUSION HERE
%
% Revision History:  <note: the first record should be the original release>
% Date		Author		SCR #		Change
% ----		------		-----		------------------------------------------
% 10/23/02	Mcar			   	    Initial version
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/ 

% local definitions
%	none	<or definitions if there are any>

% default settings
%	none	<or settings>

% external functions

% external string

% internal functions	<list of functions in this file>

% global data

% local data

% public functions

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Function description:
%	
%
%	Returns:
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/

[U,D] = compute_ud(P);
return;


% private functions

%
%
%    $History: compute_u.m $
%
