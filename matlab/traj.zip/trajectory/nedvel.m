function [V]=nedvel()
return;
