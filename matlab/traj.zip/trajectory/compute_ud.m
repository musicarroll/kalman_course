function [U,D] = compute_ud(P)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                        COPYRIGHT (C) 2002 BY                          %
%             BEI Systron Donner Inertial Division                      %
%                      CONCORD, CALIFORNIA                              %
%                      ALL RIGHTS RESERVED.                             %
%                                                                       %
% This software is furnished under a license and may be used and copied %
% only in accordance with the terms of such license and with the        %
% inclusion of the above copyright notice.  This software or any other  %
% copies thereof may not be provided or otherwise made available to any %
% other person.  No title to and ownership of the software is hereby    %
% transferred.                                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File Name:  compute_ud.m
%
%
% Related Programs and Documents:  compute_u.m, compute_d.m
%
%
% Run-time Environment Constraints:  Must run in Matlab or Simulink
%
%    DESCRIPTION:
% [U,D] = compute_ud(P)
% Computes the modified Cholesky UD factorization of 
% P, a positive definite mxm matrix.
% NOTE: M must be positive-definite and square.  This function will
% check for that.
%
%					NOT CHECKED AFTER INCLUSION HERE
%
% Revision History:  <note: the first record should be the original release>
% Date		Author		SCR #		Change
% ----		------		-----		------------------------------------------
% 10/23/02	Mcar				    Initial version
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/ 

% local definitions
%	none	<or definitions if there are any>

% default settings
%	none	<or settings>

% external functions

% external string

% internal functions	None

% global data:  None

% local data:  All

% public functions:   N/A

% private functions:  N/A

% First, check to make sure we have the right
% number of arguments to this function.
if (nargin ~= 1)
    U=[];
    D=[];
    error('compute_UD needs one argument.');
end

% Verify that P is square.

[m,n]=size(P);

if m~=n
    U=[];
    D=[];
    error('P is not square.');
    return;
end
ok=isposdef(P);
if ~ok
    error('P is not positive definite.');
end

% Input is fine, so now compute the UD factors:
for j=m:-1:1
    for i=j:-1:1
        covar=P(i,j);
        for k=j+1:m
            covar=covar-U(i,k)*D(k,k)*U(j,k);
        end
        if i==j
            D(j,j)=covar;
            U(j,j)=1;
        else
            U(i,j)=covar/D(j,j);
        end
    end
end

return;


%
%
%    $History: template.m $
%

