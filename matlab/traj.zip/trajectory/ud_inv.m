function [Minv] = ud_inv(M)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                        COPYRIGHT (C) 2002 BY                          %
%             BEI Systron Donner Inertial Division                      %
%                      CONCORD, CALIFORNIA                              %
%                      ALL RIGHTS RESERVED.                             %
%                                                                       %
% This software is furnished under a license and may be used and copied %
% only in accordance with the terms of such license and with the        %
% inclusion of the above copyright notice.  This software or any other  %
% copies thereof may not be provided or otherwise made available to any %
% other person.  No title to and ownership of the software is hereby    %
% transferred.                                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File Name:  ud_inv.m
%
%
% Related Programs and Documents:  compute_ud.m
%
%
% Run-time Environment Constraints:
%
%
%
%    DESCRIPTION:
%		This program inverts a matrix via UDU' factorizationa 
%
%					NOT CHECKED AFTER INCLUSION HERE
%
% Revision History:  <note: the first record should be the original release>
% Date		Author		SCR #		Change
% ----		------		-----		------------------------------------------
% 10/24/02	Mcar		  		    Initial version
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/ 

% local definitions
%	none	<or definitions if there are any>

% default settings
%	none	<or settings>

% external functions

% external string

% internal functions	<list of functions in this file>

% global data

% local data

% public functions

% private functions

if (nargin ~= 1)
    U=[];
    error('ud_inv needs one argument.');
end

% Verify that M is square.

[m,n]=size(M);

if m~=n
    U=[];
    error('M is not square.');
    return;
end
% First, get UD factors:
[U,D] = compute_ud(M);
% Second, invert U:
Uinv  = inv_u(U);
% 3) Invert D:
for i=1:m
    Dinv(i,i) = 1/D(i,i);
end
Minv  = Uinv'*Dinv*Uinv;
return;

%
%
%    $History: ud_inv.m $
%
