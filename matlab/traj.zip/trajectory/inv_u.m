function [Uinv] = inv_u(U)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                        COPYRIGHT (C) 2002 BY                          %
%             BEI Systron Donner Inertial Division                      %
%                      CONCORD, CALIFORNIA                              %
%                      ALL RIGHTS RESERVED.                             %
%                                                                       %
% This software is furnished under a license and may be used and copied %
% only in accordance with the terms of such license and with the        %
% inclusion of the above copyright notice.  This software or any other  %
% copies thereof may not be provided or otherwise made available to any %
% other person.  No title to and ownership of the software is hereby    %
% transferred.                                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File Name:  inv_u.m
%
%
% Related Programs and Documents:  compute_ud.m
%
%
% Run-time Environment Constraints:
%
%
%
%    DESCRIPTION:
%		This program inverts a unit upper triangular matrix.
%
%					NOT CHECKED AFTER INCLUSION HERE
%
% Revision History:  <note: the first record should be the original release>
% Date		Author		SCR #		Change
% ----		------		-----		------------------------------------------
% 10/23/02	Mcar		  		    Initial version
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/ 

% local definitions
%	none	<or definitions if there are any>

% default settings
%	none	<or settings>

% external functions

% external string

% internal functions	<list of functions in this file>

% global data

% local data

% public functions

% private functions

if (nargin ~= 1)
    U=[];
    error('inv_u needs one argument.');
end

% Verify that U is square.

[m,n]=size(U);

if m~=n
    U=[];
    error('U is not square.');
    return;
end

% Verify that U is unit upper triangular:
for i=m:-1:1
    if U(i,i) ~= 1
        error('U does not have a unit diagonal.');
    end
    for j=i-1:-1:1
        if U(i,j) ~=0
            error('U does not have zeros below the diagonal.');
        end
    end
end
Uinv=U;
for i=m:-1:1
    for j=m:-1:i+1
        Uinv(i,j)=-Uinv(i,j);
        for k=i+1:j-1
            Uinv(i,j)=Uinv(i,j)-Uinv(i,k)*Uinv(k,j);
        end
    end
end
return;



%
%
%    $History: inv_u.m $
%
