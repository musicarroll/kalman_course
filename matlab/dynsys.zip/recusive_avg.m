function [avg] = recursive_avg(prior_est,meas,gain)
  avg = zeros(1,1);
  avg = prior_est + gain*(meas-prior_est);
return;