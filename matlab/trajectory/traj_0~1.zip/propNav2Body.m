function [Cbn, Cbnl] = propNav2Body(Cbn, alpha, alpha_dot, hdg, pitch, roll, Segment, SegIndex)
% Each row of Segment contains:
% 1.   Final time
% 2.   Time step  
% 3.   Final heading
% 4.   Centripital turn acceleration (g's)
% 5.   Final total velocity
% 6.   Longitudinal acceleration (g's)
% 7.   Final altitude
% 8.   Altitude rate  
% 9.   Vertical acceleration (g's)
% 10.  Pitch angle (climb or dive)   

time_step  = Segment(SegIndex,2); % delta Tn

Cbnl = Cbn;  % store previous transformation

alpha = alpha + alpha_dot*time_step;  % extrapolate wander angle

true_hdg = hdg + alpha; % compute true heading

Cbn = euler2DCM (roll,pitch,true_hdg);

return;
