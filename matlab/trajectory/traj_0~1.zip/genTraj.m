% Script genTraj.m
% This Matlab script generates the trajectory
% from the user-specified trajectory file 
if ~exist('file_loaded')
    filename = input('Enter name of trajectory spec file: ','s');
end
load(filename);

% The following calls would be encapsulated in initTraj.m

[roll,pitch,yaw,alpha,Cbn] = getInitAttitude(roll0,pitch0,hdg0);
hdg = yaw;%

% Velocity vector:
[Vned, Vh, Vv] = getInitVelocity(vel0,Cbn,pitch);
V = norm(Vned);

[POSgeo] = getInitPosition(lat0,lon0,alt0);

lat = POSgeo(1);
lon = POSgeo(2);
alt = POSgeo(3);

% Calculate ECEF position:

[POSecef] = geo2ecef(lat,lon,alt);

[g] = getInitGravity(alt);

[Aned] = getInitSensedAccel(alt);

% Change 12/26/03: omegaB (inertial) -> omegaBbar (body) rates:
[omegaBbar] = getInitBodyRates;

[T] = getInitTime;

[SegIndex] = getInitSegIndex;


% Call execTraj.m

Trajectory = zeros(1,19);
RelRates = zeros(1,5);
Cbn_array(1).Cbn = zeros(3,3);
Cbn_array(1).Cbn = Cbn;
% Change 12/26/03: Using omegaBbar instead of omegaB, since the latter quantity
% (which has now been renamed to omega) is inertial, not body, while we need
% to record body rates here in the Trajectory array.
Trajectory(1,:) = [T,Aned(1),Aned(2),Aned(3),Vned(1),Vned(2),Vned(3),...
        POSecef(1),POSecef(2),POSecef(3),lat, lon, alt,...
        omegaBbar(1),omegaBbar(2),omegaBbar(3), roll, pitch, hdg];
i=1;  % Trajectory record index
status = 0; % Determines is simulation is finished.

while (status==0) 

% Time Logic (6.1):

    [status,T,SegIndex] = incrTime(T,SegIndex,Segment,num_segs);
    if status==1
        break;
    else
        i = i+1;  % increment Trajectory record index.
    end
    
% Heading Change Logic (6.2):

    [hdg,cmd_roll] = procHeadingChange(hdg,SegIndex,Segment,hdg_rate_limit,g, Vh);

% Roll Change Logic (6.3):

    [roll] = procRollChange(roll,cmd_roll,SegIndex,Segment,roll_rate_limit,g, Vh);

% Altitude Change Logic (6.4):

    [alt, Av] = procAltitudeChange(alt,SegIndex,Segment,pitch_rate_limit,g,V, Vv);

% Velocity Change Logic (6.5):

    [V] = procVelocityChange(V,SegIndex,Segment,g, Vh);

% Compute pitch angle (6.6):

    [pitch] = compPitch(V, Cbn);

% Compute relative rates (6.7):

    [rho_n,rho_e,rho_d,alpha_dot, Rlat, Rlon] = compRelRates(V, Cbn, lat, alt, seg_type);

    rho = [rho_n;rho_e;rho_d];

% Extrapolate Nav to Body Transformation

    [Cbn, Cbnl] = propNav2Body(Cbn, alpha, alpha_dot, hdg, pitch, roll, Segment, SegIndex);

% Velocity Calculations (6.9)

    [Vned, avg_vel, avg_vel_rate] = compVelocity(Vned, V, Cbn, SegIndex, Segment);

% Position Calculations (6.10)

    [POSecef, POSgeo] = compPosition(POSgeo, avg_vel, Rlat, Rlon, SegIndex, Segment);
    lat = POSgeo(1);
    lon = POSgeo(2);
    alt = POSgeo(3);
    
% Inertial Angular Rates (6.11)

% Change 12/26/03: omegaB renamed to omega for inertial rates:
    [omega, omegaC] = compInertialRates(lat, rho);

% Average Sensed Accelerations (6.12)
% Added 1/2/04: Return acceleration vector in Nav coordinates:

    [accel_vec_body,accel_vec_nav] = compAvgSensedAccel(lat,alt, avg_vel, avg_vel_rate, omegaC, Cbn, Cbnl);
% accel_vec_nav is actually in NED already, since wander angle has been taken out:
    Aned = accel_vec_nav;
    
    
% Average Body Rates (6.13)

% Change 12/-26/03: Renamed omegaB to omega to reflect the fact that
% this quantity is really an inertial rate, not a body rate:

    [omegaBbar]=compAvgBodyRates(Cbn,Cbnl, omega, SegIndex, Segment);

% Add record to trajectory:
% Watch out for empty arrays, e.g., roll=[].  This will change
% the number of columns in the record below.
% Change 12/26/03: omegaB (inertial rates) -> omegaBbar (body rates) 
Trajectory(i,:) = [T,Aned(1),Aned(2),Aned(3),Vned(1),Vned(2),Vned(3),...
                    POSecef(1),POSecef(2),POSecef(3),lat, lon, alt,...
                    omegaBbar(1),omegaBbar(2),omegaBbar(3), roll, pitch, hdg];

RelRates(i,:) = [T,rho_n,rho_e,rho_d,alpha_dot];            
Cbn_array(i).Cbn = Cbn;
end

disp('Trajectory Generation Complete.');
if exist('author')
    disp(['Scenario author: ',author]);
    disp(['Description: ',description]);
    disp(final_comments);
end


% Call saveTraj.m