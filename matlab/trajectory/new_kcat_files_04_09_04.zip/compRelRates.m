function [rho_n, rho_e, rho_d, alpha_dot, Rlat, Rlon] = compRelRates(V, Cbn, lat, alt, seg_type)
% compRelRates.m computes relative rates.
% as outlined in section 6.7:

Vned = Cbn*[V;0;0];
Vn = Vned(1);
Ve = Vned(2);

[Rlat, Rlon, ae, D] = getRadii(lat, alt);
% Trying to flip sign.  Was:
%rho_n = Ve/Rlon;
%rho_e = -Vn/Rlat;
% Is (4/7/04 -- discrepancy between cmigits.pdf and Cruise Spec:
rho_n = -Ve/Rlon;
rho_e = Vn/Rlat;
% 0=great circle; 1=rhumb line
if seg_type ==1  % rhumb line
	rho_d = - rho_n * tan(lat);
	alpha_dot = 0;
else    % great circle
	rho_d = 0;
	alpha_dot = rho_n*tan(lat);
end

return;

    
    